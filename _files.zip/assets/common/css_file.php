   <!-- Fav Icon -->
   <link rel="icon" href="assets/img/favicon.png" type="image/x-icon">
  <!-- plugins css -->
	<link rel="stylesheet" href="assets/vendors/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/vendors/fontawesome/css/all.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="assets/css/style1.css">
	<link rel="stylesheet" href="assets/css/responsive.css">

	<link rel="stylesheet" href="assets/plugins/dataTables/css/bootstrap.css">
	<link rel="stylesheet" href="assets/plugins/dataTables/css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" href="assets/plugins/dataTables/css/responsive.bootstrap4.min.css">
	