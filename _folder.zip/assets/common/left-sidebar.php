    <div class="col-lg-2 sticky-top">
            <div class="d-flex flex-sm-column flex-row flex-nowrap align-items-center sticky-top">
                <a href="#" class="d-block p-3 link-dark text-decoration-none" title="" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Icon-only">
                    <i class="bi-bootstrap fs-1"></i>
                </a>
                <ul class="nav nav-pills nav-flush flex-sm-column flex-row flex-nowrap mb-auto mx-auto text-center justify-content-between w-100 px-3 align-items-center">
                   <!-- <li class="nav-item">-->
					 <li>
                        <a href="#" class="nav-link py-3 px-2" title="" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Home">
                           <img src="assets/img/sidebar/01.png" class=" text-center " alt="...">
							 <h4>Sales Invoice</h4>
                        </a>
                    </li>
                    <li>
                        <a href="all-product.php" class="nav-link py-3 px-2" title="" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Dashboard">
                              <img src="assets/img/sidebar/02.png" class=" text-center " alt="...">
							 <h4>      Place  Orders
</h4>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="nav-link py-3 px-2" title="" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Orders">
                               <img src="assets/img/sidebar/03.png" class=" text-center " alt="...">
							 <h4>Token Master
</h4>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="nav-link py-3 px-2" title="" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Products">
                             <img src="assets/img/sidebar/02.png" class=" text-center " alt="...">
							 <h4>My  Orders
</h4>
                        </a>
                    </li>
					
					 <li>
                        <a href="#" class="nav-link py-3 px-2" title="" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Products">
                              <img src="assets/img/sidebar/03.png" class=" text-center " alt="...">
							 <h4>SOC Check
</h4>
                        </a>
                    </li>
					
					 <li>
                        <a href="#" class="nav-link py-3 px-2" title="" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-original-title="Products">
                               <img src="assets/img/sidebar/01.png" class=" text-center " alt="...">
							 <h4>Stock Check
</h4>
                        </a>
                    </li>
					

                </ul>
              
            </div>
        </div>
     
        