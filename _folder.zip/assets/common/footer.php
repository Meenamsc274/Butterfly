<!-- Footer -->
<footer class="text-center text-lg-start bg-light text-muted">
 
  <!-- Copyright -->
  <div class="copyright text-center p-4" >
   
    
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->