
 <!----header----->
  <header>
         <div class="header_area">
	 
  <div class="container-fluid">
    <div class="row">
    <div class="col-lg-3">
    <a class="navbar-brand" href="#">   <img src="assets/img/logo.png" alt="logo" ></a>
	</div>
	 <div class="col-lg-9">
	<div class="nav-right-top">
	   <div class="setting-icon">
	<!-- <a href="#"> <i class="fa fa-cog"></i></a>
		  <a href="#">   <i class="fa fa-ellipsis-h"></i></a>-->
		  <a href="#"> <img src="assets/img/set-icon.png" alt="" ></a>&nbsp;&nbsp;
		 <a href="#" class="appicon" > <img src="assets/img/app-icon.png" alt="" ></a>
		  
		  
		   </div>
		   <br>
		   
		    <div class="factory">
		   
		   <ul class="list-unstyled">
   <li>Type : Factory Outlet
</li>
   <li>State : Tamil Nadu
</li>
  <li>District :  Chengalpattu
</li>
   <li>Store : 1796 
</li>
   
</ul>
</div>
	</div>
	</div>
		</div>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
	<!-- mobile icon -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
	
	
	
	
	
    
	
<!-- menu -->
  
<div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">DASHBOARD
</a>
        </li>
         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"> 
            Master 
          </a>
          <ul class="dropdown-menu scrollable-menu" aria-labelledby="navbarDropdown">
          	 <li>
            	<a class="dropdown-item" href="#"> Industry &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="industry_add.php"> Industry Add</a></li>
				   			<li><a class="dropdown-item" href="industry_view.php"> Industry View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Country &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="country_add.php"> Country Add</a></li>
				   			<li><a class="dropdown-item" href="country_view.php"> Country View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> State &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="state_add.php"> State Add</a></li>
				   			<li><a class="dropdown-item" href="state_view.php"> State View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> District &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="district_add.php"> District Add</a></li>
				   			<li><a class="dropdown-item" href="district_view.php"> District View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> City &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="city_add.php"> City Add</a></li>
				   			<li><a class="dropdown-item" href="city_view.php"> City View</a></li>
	            </ul>
	          </li>
	           <li>
            	<a class="dropdown-item" href="#"> Pincode &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="pincode_add.php"> Pincode Add</a></li>
				   			<li><a class="dropdown-item" href="pincode_view.php"> Pincode View</a></li>
	            </ul>
	          </li>
	           <li>
            	<a class="dropdown-item" href="#"> Company &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="company_add.php"> Company Add</a></li>
				   			<li><a class="dropdown-item" href="company_view.php"> Company View</a></li>
	            </ul>
	          </li>
	           <li>
            	<a class="dropdown-item" href="#"> Branch &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="branch_add.php"> Branch Add</a></li>
				   			<li><a class="dropdown-item" href="branch_view.php"> Branch View</a></li>
	            </ul>
	          </li>
	           <li>
            	<a class="dropdown-item" href="#"> Warehouse &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="warehouse_add.php"> Warehouse Add</a></li>
				   			<li><a class="dropdown-item" href="warehouse_view.php"> Warehouse View</a></li>
	            </ul>
	          </li>
	           <li>
            	<a class="dropdown-item" href="#"> Category &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="category_add.php"> Category Add</a></li>
				   			<li><a class="dropdown-item" href="category_view.php"> Category View</a></li>
	            </ul>
	          </li>
	           <li>
            	<a class="dropdown-item" href="#"> Subcategory &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="subcategory_add.php"> Subcategory Add</a></li>
				   			<li><a class="dropdown-item" href="subcategory_view.php"> Subcategory View</a></li>
	            </ul>
	          </li>
	           <li>
            	<a class="dropdown-item" href="#"> Currency &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="currency_add.php"> Currency Add</a></li>
				   			<li><a class="dropdown-item" href="currency_view.php"> Currency View</a></li>
	            </ul>
	          </li>
	           <li>
            	<a class="dropdown-item" href="#"> Brand &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="brand_add.php"> Brand Add</a></li>
				   			<li><a class="dropdown-item" href="brand_view.php"> Brand View</a></li>
	            </ul>
	          </li>
	           <li>
            	<a class="dropdown-item" href="#"> Deliverypartner &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="deliverypartner_add.php"> Deliverypartner Add</a></li>
				   			<li><a class="dropdown-item" href="deliverypartner_view.php"> Deliverypartner View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Department &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="department_add.php"> Department Add</a></li>
				   			<li><a class="dropdown-item" href="department_view.php"> Department View</a></li>
	            </ul>
	          </li>
	          
	          <li>
            	<a class="dropdown-item" href="#"> Designation &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="designation_add.php"> Designation Add</a></li>
				   			<li><a class="dropdown-item" href="designation_view.php"> Designation View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Floor &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="floor_add.php"> Floor Add</a></li>
				   			<li><a class="dropdown-item" href="floor_view.php"> Floor View</a></li>
	            </ul>
	          </li>
	         
	          <li>
            	<a class="dropdown-item" href="#"> Layout &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="layout_add.php"> Layout Add</a></li>
				   			<li><a class="dropdown-item" href="layout_view.php"> Layout View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Section &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="section_add.php"> Section Add</a></li>
				   			<li><a class="dropdown-item" href="section_view.php"> Section View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Table &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="table_add.php"> Table Add</a></li>
				   			<li><a class="dropdown-item" href="table_view.php"> Table View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Tag &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="tag_add.php"> Tag Add</a></li>
				   			<li><a class="dropdown-item" href="tag_view.php"> Tag View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Sms &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="sms_add.php"> Sms Add</a></li>
				   			<li><a class="dropdown-item" href="sms_view.php"> Sms View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Notification &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="notification_add.php"> Notification Add</a></li>
				   			<li><a class="dropdown-item" href="notification_view.php"> Notification View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Status &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="status_add.php"> Status Add</a></li>
				   			<li><a class="dropdown-item" href="status_view.php"> Status View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Accountcategory &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="accountcategory_add.php"> Accountcategory Add</a></li>
				   			<li><a class="dropdown-item" href="accountcategory_view.php"> Accountcategory View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Bank &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="bank_add.php"> Bank Add</a></li>
				   			<li><a class="dropdown-item" href="bank_view.php"> Bank View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Tax &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="tax_add.php"> Tax Add</a></li>
				   			<li><a class="dropdown-item" href="tax_view.php"> Tax View</a></li>
	            </ul>
	          </li>
	          
	          <li>
            	<a class="dropdown-item" href="#"> Unit &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="unit_add.php"> Unit Add</a></li>
				   			<li><a class="dropdown-item" href="unit_view.php"> Unit View</a></li>
	            </ul>
	          </li>
	          <li>
            	<a class="dropdown-item" href="#"> Menu &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="menu_add.php"> Menu Add</a></li>
				   			<li><a class="dropdown-item" href="menu_view.php"> Menu View</a></li>
	            </ul>
	          </li>
             <li>
            	<a class="dropdown-item" href="#"> Userrights &raquo;  </a>
	            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
	              <li><a class="dropdown-item" href="userrights_add.php"> Userrights Add</a></li>
				   			<li><a class="dropdown-item" href="userrights_view.php"> Userrights View</a></li>
	            </ul>
	          </li>
				   <li><hr class="dropdown-divider"></li>
				
		
					 
          </ul>
        </li>
		
        <li class="nav-item ">
         
		  
		   <a class="nav-link" aria-current="page" href="#">Finance
</a>
          
        </li>
		
		 <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Accounts  
          </a>
          <ul class="dropdown-menu scrollable-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#">Cash Account</a></li>
            <li><a class="dropdown-item" href="#">Opening Balance List</a></li>
          <!--  <li><hr class="dropdown-divider"></li>-->
            <li><a class="dropdown-item" href="#">Bank Statement</a></li>
            <li><a class="dropdown-item" href="#">DayBook</a></li>
			  <li><a class="dropdown-item" href="#">Daily Cash Report</a></li>
            <li><a class="dropdown-item" href="#">Ledger</a></li>
			  <li><a class="dropdown-item" href="#">Trial Balance - Full</a></li>
			    <li><a class="dropdown-item" href="#">Profit & Loss - Full</a></li>
				  <li><a class="dropdown-item" href="#">Balance Sheet - Full</a></li>
				    <li><a class="dropdown-item" href="#">Trial Balance - Datewise</a></li>
					   <li><a class="dropdown-item" href="#">Profit & Loss - Datewise</a></li>
				  <li><a class="dropdown-item" href="#">Balance Sheet - Datewise</a></li>
			
          </ul>
        </li>
		
		 <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Inventory  
          </a>
          <ul class="dropdown-menu scrollable-menu" aria-labelledby="navbarDropdown">
           
		  <li>
		  	<a class="dropdown-item" href="#"> Purchases &raquo;</a>
			  <ul class="dropdown-menu scrollable-menu dropdown-submenu">
			  	<li>
                	<a class="dropdown-item" href="#"> Purchase Order &raquo; </a>
					<ul class="dropdown-menu scrollable-menu dropdown-submenu">
                  		<li><a class="dropdown-item" href="purchaseorderdetails_add.php">Purchase Order Add</a></li>
                  		<li><a class="dropdown-item" href="purchaseorder_view.php">Purchase Order View</a></li>
					</ul>
				</li>
				<li>
                	<a class="dropdown-item" href="#"> Purchase &raquo; </a>
					<ul class="dropdown-menu scrollable-menu dropdown-submenu">
                  		<li><a class="dropdown-item" href="purchasedetails_add.php">Purchase  Add</a></li>
                  		<li><a class="dropdown-item" href="purchase_view.php">Purchase View</a></li>
					</ul>
				</li>
				<li>
                	<a class="dropdown-item" href="#"> Purchase Ingredient &raquo; </a>
					<ul class="dropdown-menu scrollable-menu dropdown-submenu">
                  		<li><a class="dropdown-item" href="purchaseingredientdetails_add.php">Purchase Ingredient Add</a></li>
                  		<li><a class="dropdown-item" href="purchaseingredient_view.php">Purchase Ingredient View</a></li>
					</ul>
				</li>
				<li>
                	<a class="dropdown-item" href="#"> Purchase Return &raquo; </a>
					<ul class="dropdown-menu scrollable-menu dropdown-submenu">
                  		<li><a class="dropdown-item" href="purchasereturndetails_add.php">Purchase Return Add</a></li>
                  		<li><a class="dropdown-item" href="purchasereturn_view.php">Purchase Return View</a></li>
					</ul>
				</li>
				<li>
                	<a class="dropdown-item" href="#"> Purchase Ingredient Return &raquo; </a>
					<ul class="dropdown-menu scrollable-menu dropdown-submenu">
                  		<li><a class="dropdown-item" href="purchaseingredientreturndetails_add.php">Purchase Ingredient Return Add</a></li>
                  		<li><a class="dropdown-item" href="purchaseingredientreturn_view.php">Purchase Ingredient Return View</a></li>
					</ul>
				</li>
			  </ul>
			
		  </li>
		  <li>
		  	<a class="dropdown-item" href="#"> Sales &raquo;</a>
			  <ul class="dropdown-menu scrollable-menu dropdown-submenu">
			  	<li>
                	<a class="dropdown-item" href="#"> Sales &raquo; </a>
					<ul class="dropdown-menu scrollable-menu dropdown-submenu">
                  		<li><a class="dropdown-item" href="pos.php">POS</a></li>
                  		<li><a class="dropdown-item" href="sales_add.php">Sales Add</a></li>
				     	<li><a class="dropdown-item" href="sales_view.php">Sales View</a></li>
					</ul>
				</li>
				<li>
                	<a class="dropdown-item" href="#"> Sales Return &raquo; </a>
					<ul class="dropdown-menu scrollable-menu dropdown-submenu">
						<li><a class="dropdown-item" href="salesreturndetails_add.php">Sales Return Add</a></li>
				     	<li><a class="dropdown-item" href="salesreturn_view.php">Sales Return View</a></li>
					</ul>
				</li>
			  </ul>
			
		  </li>
               <li>
            <a class="dropdown-item" href="#">
          Transactions &raquo;
            </a>
            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
			
             
                <a class="dropdown-item" href="#"> Stocks &raquo; </a>
                <ul class="dropdown-menu scrollable-menu dropdown-submenu">
                  <li>
                    <a class="dropdown-item" href="#">Shortage In Stocks</a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="#">Exceses In Stocks</a>
                  </li>
				     <li>
                     <a class="dropdown-item" href="#">Stock Transfers</a>
                  </li>
				     <li>
                     <a class="dropdown-item" href="#">Opening Stocks</a>
                  </li>
				    <li>
                     <a class="dropdown-item" href="#">Material  Requisition</a>
                  </li>
                </ul>
              </li>
              <li>
                <a class="dropdown-item" href="#">Hold/Unhold Stocks</a>
              </li>
              <li>
                <a class="dropdown-item" href="#">Stock Allocation</a>
              </li>
            </ul>
          </li>
            <li><hr class="dropdown-divider"></li>
			
			  <li><a class="dropdown-item" href="#">  Reports  </a></li>
			    <li><a class="dropdown-item" href="#"> order Management </a></li>
           
          </ul>
        </li>
		
		 <li class="nav-item">
         <!-- <a class="nav-link dropdown-toggle" href="golden-ratio.php" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Butterfly Auditor  
          </a>-->
		  
		    <a class="nav-link active" aria-current="page" href="golden-ratio.php"> Butterfly Auditor  
</a>
        <!--  <ul class="dropdown-menu scrollable-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#">  Butterfly Auditor </a></li>
           
            <li><a class="dropdown-item" href="#">  Butterfly Auditor </a></li>
			   <li><hr class="dropdown-divider"></li>
			
            <li><a class="dropdown-item" href="#">  Butterfly Auditor </a></li>
			 <li><a class="dropdown-item" href="#">  Butterfly Auditor 1</a></li>
			 
			           <li>
            <a class="dropdown-item" href="#">
            Butterfly Auditor 2 &raquo;
            </a>
            <ul class="dropdown-menu scrollable-menu dropdown-submenu">
              <li>
                <a class="dropdown-item" href="#"> Butterfly Auditor 2- 1</a>
              </li>
              <li>
                <a class="dropdown-item" href="#"> Butterfly Auditor 2- 2</a>
              </li>
              <li>
                <a class="dropdown-item" href="#"> Butterfly Auditor 2- 3 &raquo; </a>
                <ul class="dropdown-menu scrollable-menu dropdown-submenu">
                  <li>
                    <a class="dropdown-item" href="#">Butterfly Auditor 2- 3- 1</a>
                  </li>
                  <li>
                    <a class="dropdown-item" href="#">Butterfly Auditor  2- 3- 2</a>
                  </li>
                </ul>
              </li>
              <li>
                <a class="dropdown-item" href="#">Butterfly Auditor 3</a>
              </li>
              <li>
                <a class="dropdown-item" href="#">Butterfly Auditor 4</a>
              </li>
            </ul>
          </li> 
         
         </ul>-->
        </li>
		
		<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           My Reports  
          </a>
          <ul class="dropdown-menu scrollable-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#"> GST  Report </a></li>
            <li><a class="dropdown-item" href="#">  GST Group Report </a></li>
			 <li><a class="dropdown-item" href="#">  GST Portal Report </a></li>
            <li><a class="dropdown-item" href="#">  Sales Analysis Reports </a></li>
			  <li><a class="dropdown-item" href="#">  Sales Stock Analysis Reports </a></li>
			   <li><a class="dropdown-item" href="#">  GST Portal Group Report 1</a></li>
			      <li><a class="dropdown-item" href="#">  GST Portal Group Report 2</a></li>
				     <li><a class="dropdown-item" href="#">  GST Portal Group Report 3</a></li>
		
           
          </ul>
        </li>


      </ul>
     <div class="">
	 <div class="cart-icon margin-right-10">
	  <div class="dropdown">
  <a class="text-white dropdown-toggle" data-bs-toggle="dropdown">
   <i class="fa fa-user"></i> <?php echo $_SESSION['user_name']; ?>
  </a>
  <ul class="dropdown-menu scrollable-menu" aria-labelledby="navbarDropdown">
    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
    
  </ul>
</div>
		   </div>
		   
			
		   
		   
	 </div>	  
  
	<div class="">
	 <div class="cart-icon">
	  <a href="#">  <i class="fa fa-shopping-cart"></i>
		 <span>My Cart</span></a>
		   </div>
		   
		<div class="cart-expand">
		
		 <div class="row">
	  
	 
	
    <div class="col-lg-4">
	<div class="cart-sale ">
<a href="#"><img src="assets/img/cart/icon-1.png" alt="cart" ></a>
<p><a href="#">Schemes
</a></p>
	</div>	
	</div>	
	
	 <div class="col-lg-4">
	<div class="cart-sale ">
	<a href="#"><img src="assets/img/cart/icon-2.png" alt="cart" ></a>
	<p><a href="#">  B. Analytics
</a></p>
	</div>	
	</div>	
	
	 <div class="col-lg-4">
	<div class="cart-sale ">
<a href="#"><img src="assets/img/cart/icon-3.png" alt="cart" ></a>
<p><a href="#">Marketing
</a></p>
	</div>	
	</div>	
	</div>
	 <div class="row">
		
    <div class="col-lg-4">
	<div class="cart-sale ">
<a href="#"><img src="assets/img/cart/icon-4.png" alt="cart" ></a>
<p><a href="#">My  Complaints
</a></p>
	</div>	
	</div>	
	
	 <div class="col-lg-4">
	<div class="cart-sale ">
	<a href="#"><img src="assets/img/cart/icon-5.png" alt="cart" ></a>
	<p><a href="#">Fixed Asset
</a></p>
	</div>	
	</div>	
	
	 <div class="col-lg-4">
	<div class="cart-sale ">
<a href="#"><img src="assets/img/cart/icon-6.png" alt="cart" ></a>
<p><a href="#">SOP</a></p>
	</div>	
	</div>	
	</div>	
	 <div class="row">
	  
	 
	
    <div class="col-lg-4">
	<div class="cart-sale ">
<a href="#"><img src="assets/img/cart/icon-7.png" alt="cart" ></a>
<p><a href="#">HRM
</a></p>
	</div>	
	</div>	
	
	 <div class="col-lg-4">
	<div class="cart-sale ">
	<a href="#"><img src="assets/img/cart/icon-8.png" alt="cart" ></a>
	<p><a href="#">  CRM
</a></p>
	</div>	
	</div>	
	
	 <div class="col-lg-4">
	<div class="cart-sale ">
<a href="#"><img src="assets/img/cart/icon-10.png" alt="cart" ></a>
<p><a href="#">Risk Management
</a></p>
	</div>	
	</div>	
	</div>
		<br>
</div>		
		   
		   
	 </div>	   
	
  </div>
  
   
  
</nav>
		 </div>



</div>
  </header>
  
